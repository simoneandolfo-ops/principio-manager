# Principio Tablet Notifier 1.0.0

Prima base Android nativa per i due tablet operativi di Principio.

## Funzionamento
- Alla prima apertura inserire il PIN dell'operatore già presente su Aruba (`Tablet interna` / `Tablet esterna`).
- L'app registra il tablet sul Manager 4.2.13.
- Richiede una sola volta il permesso Android **Mostra sopra altre app**.
- Durante la fascia operativa 17:00–02:30 controlla il Centro Notifiche ogni 8 secondi.
- Se trova una notifica non letta, mostra una card persistente in alto a destra.
- La card non sparisce finché non viene toccata.
- Il tap marca la notifica come letta su Aruba e apre la prenotazione esistente nel Manager.
- Se ci sono più notifiche, viene mostrata prima la più vecchia non vista e viene indicato il totale da vedere.
- Il servizio si riavvia dopo il boot se il tablet è già collegato e Android consente l'overlay.

## Backend richiesto
Installare prima `Principio_Manager_4.2.13_ANDROID_TABLET_NOTIFIER_SAFE.zip` su `/manager4/`.

## Build
Aprire questa cartella in Android Studio (JDK 17), attendere il sync Gradle e usare **Build > Build APK(s)**.
APK: `app/build/outputs/apk/debug/app-debug.apk` (debug) oppure configurare una chiave di firma per la release.

## Nota tecnica
La V1 usa polling HTTPS SAFE ogni 8 secondi invece di Firebase/FCM: per soli due tablet è leggero, non richiede credenziali esterne e riusa direttamente il Centro Notifiche già esistente. In una release successiva il trasporto può essere sostituito da FCM lasciando invariati accesso operatore, overlay e presa visione.
