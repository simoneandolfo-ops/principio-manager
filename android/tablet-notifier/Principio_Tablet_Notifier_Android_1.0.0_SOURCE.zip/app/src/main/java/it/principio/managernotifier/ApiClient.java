package it.principio.managernotifier;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

final class ApiClient {
    static JSONObject call(String fn, JSONArray args) throws Exception {
        URL url=new URL(BuildConfig.MANAGER_BASE_URL+"api.php");
        HttpURLConnection c=(HttpURLConnection)url.openConnection();
        c.setConnectTimeout(9000); c.setReadTimeout(12000); c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setRequestProperty("Content-Type","application/json; charset=utf-8");
        JSONObject req=new JSONObject(); req.put("fn",fn); req.put("args",args);
        byte[] body=req.toString().getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(body.length);
        try(OutputStream os=c.getOutputStream()){ os.write(body); }
        int status=c.getResponseCode();
        InputStream is=(status>=200&&status<300)?c.getInputStream():c.getErrorStream();
        String text=read(is); JSONObject out=new JSONObject(text.isEmpty()?"{}":text);
        if(status<200||status>=300||!out.optBoolean("ok",false)) throw new IOException(out.optString("error","Errore server "+status));
        return out.optJSONObject("result")!=null?out.getJSONObject("result"):new JSONObject().put("value",out.opt("result"));
    }
    private static String read(InputStream is) throws IOException {
        if(is==null)return ""; ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] buf=new byte[4096]; int n;
        while((n=is.read(buf))!=-1)b.write(buf,0,n); return b.toString(StandardCharsets.UTF_8);
    }
}
