package it.principio.managernotifier;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.UUID;

final class Prefs {
    private static final String FILE="principio_notifier";
    static SharedPreferences p(Context c){ return c.getSharedPreferences(FILE,Context.MODE_PRIVATE); }
    static String token(Context c){ return p(c).getString("token",""); }
    static String operator(Context c){ return p(c).getString("operator",""); }
    static void saveLogin(Context c,String token,String operator){ p(c).edit().putString("token",token).putString("operator",operator).apply(); }
    static void clear(Context c){ p(c).edit().clear().apply(); }
    static String deviceId(Context c){
        String v=p(c).getString("device_id","");
        if(v.isEmpty()){ v=UUID.randomUUID().toString(); p(c).edit().putString("device_id",v).apply(); }
        return v;
    }
}
