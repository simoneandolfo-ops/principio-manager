package it.principio.managernotifier;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.time.LocalTime;
import java.util.concurrent.*;

public class NotifierService extends Service {
    private static final String CHANNEL="principio_notifier_service";
    private final ScheduledExecutorService exec=Executors.newSingleThreadScheduledExecutor();
    private WindowManager wm; private View overlay; private long shownId=-1; private String start="17:00",end="02:30"; private int poll=8;

    @Override public void onCreate(){super.onCreate(); createChannel(); startForeground(21,serviceNotification("Principio Notifier attivo")); wm=(WindowManager)getSystemService(WINDOW_SERVICE);}
    @Override public int onStartCommand(Intent i,int flags,int id){ if(Prefs.token(this).isEmpty())return START_NOT_STICKY; exec.scheduleWithFixedDelay(this::pollSafe,0,poll,TimeUnit.SECONDS); return START_STICKY; }
    @Override public void onDestroy(){exec.shutdownNow();hideOverlay();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}

    private void pollSafe(){try{pollNow();}catch(Exception ignored){}}
    private void pollNow() throws Exception {
        String token=Prefs.token(this); if(token.isEmpty())return;
        JSONObject r=ApiClient.call("tabletNotifierPoll",new JSONArray().put(token).put(Prefs.deviceId(this)).put(BuildConfig.VERSION_NAME).put(20));
        JSONObject cfg=r.optJSONObject("config"); if(cfg!=null){start=cfg.optString("workStart",start);end=cfg.optString("workEnd",end);poll=Math.max(5,cfg.optInt("pollSeconds",poll));}
        JSONArray rows=r.optJSONArray("rows");
        if(rows==null||rows.length()==0||!inWorkHours()){runOnMain(this::hideOverlay);return;}
        JSONObject item=rows.getJSONObject(rows.length()-1); // oldest unseen first: nothing gets buried
        long id=item.optLong("id",0); if(id<=0)return;
        if(id!=shownId){shownId=id;alert();}
        runOnMain(()->showOverlay(item,rows.length()));
    }
    private boolean inWorkHours(){
        try{LocalTime now=LocalTime.now(),s=LocalTime.parse(start),e=LocalTime.parse(end); if(s.equals(e))return true; return s.isBefore(e)?(!now.isBefore(s)&&now.isBefore(e)):(!now.isBefore(s)||now.isBefore(e));}catch(Exception x){return true;}
    }
    private void alert(){
        try{Uri u=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);RingtoneManager.getRingtone(this,u).play();}catch(Exception ignored){}
        try{android.os.Vibrator v=(android.os.Vibrator)getSystemService(VIBRATOR_SERVICE);if(v!=null){if(Build.VERSION.SDK_INT>=26)v.vibrate(android.os.VibrationEffect.createWaveform(new long[]{0,250,100,250},-1));else v.vibrate(400);}}catch(Exception ignored){}
    }
    private void showOverlay(JSONObject item,int count){
        if(!Settings.canDrawOverlays(this))return; hideOverlay();
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(15),dp(18),dp(15));
        GradientDrawable bg=new GradientDrawable();bg.setColor(Color.WHITE);bg.setCornerRadius(dp(18));bg.setStroke(dp(2),Color.rgb(185,149,79));box.setBackground(bg);box.setElevation(dp(10));
        TextView type=new TextView(this);type.setText(typeLabel(item.optString("event_type")));type.setTextSize(13);type.setTextColor(Color.rgb(151,121,58));type.setTypeface(null,1);box.addView(type);
        TextView title=new TextView(this);title.setText(item.optString("title","Nuova notifica"));title.setTextSize(19);title.setTextColor(Color.rgb(20,20,20));title.setTypeface(null,1);box.addView(title);
        TextView body=new TextView(this);body.setText(item.optString("body",""));body.setTextSize(15);body.setTextColor(Color.rgb(70,70,70));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.setMargins(0,dp(4),0,dp(7));box.addView(body,bp);
        TextView action=new TextView(this);action.setText((count>1?"TOCCA PER APRIRE · "+count+" DA VEDERE":"TOCCA PER APRIRE"));action.setTextSize(12);action.setTextColor(Color.rgb(21,21,21));action.setTypeface(null,1);box.addView(action);
        long nid=item.optLong("id",0);String bid=item.optString("entity_id","");box.setOnClickListener(v->ackAndOpen(nid,bid));
        int typeWindow=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(dp(360),WindowManager.LayoutParams.WRAP_CONTENT,typeWindow,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.END;lp.x=dp(18);lp.y=dp(18);overlay=box;try{wm.addView(box,lp);}catch(Exception e){overlay=null;}
    }
    private String typeLabel(String t){switch(t){case "customer_booking":return "APP CLIENTI";case "manual_booking":return "PRENOTAZIONE MANUALE";case "booking_updated":return "PRENOTAZIONE MODIFICATA";default:return "PRINCIPIO MANAGER";}}
    private void ackAndOpen(long nid,String bookingId){ hideOverlay(); shownId=-1; exec.execute(()->{try{ApiClient.call("tabletNotifierMarkRead",new JSONArray().put(Prefs.token(this)).put(nid));}catch(Exception ignored){} runOnMain(()->{Uri u=Uri.parse(BuildConfig.MANAGER_BASE_URL+(bookingId.isEmpty()?"":"?push_booking="+Uri.encode(bookingId)));Intent in=new Intent(Intent.ACTION_VIEW,u);in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(in);});}); }
    private void hideOverlay(){if(overlay!=null){try{wm.removeView(overlay);}catch(Exception ignored){}overlay=null;}}
    private void runOnMain(Runnable r){new Handler(Looper.getMainLooper()).post(r);}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"Principio Notifier",NotificationManager.IMPORTANCE_LOW);c.setDescription("Servizio operativo dei tablet Principio");getSystemService(NotificationManager.class).createNotificationChannel(c);}}
    private Notification serviceNotification(String text){Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);return b.setSmallIcon(it.principio.managernotifier.R.drawable.ic_principio).setContentTitle("Principio Manager").setContentText(text).setOngoing(true).setContentIntent(pi).build();}
}
