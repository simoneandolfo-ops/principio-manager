package it.principio.managernotifier;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private LinearLayout root; private TextView status; private EditText pin; private Button login;
    private final int gold=Color.rgb(185,149,79), ink=Color.rgb(21,21,21), bg=Color.rgb(250,248,243);
    @Override public void onCreate(Bundle b){super.onCreate(b);render();}
    @Override protected void onResume(){super.onResume(); if(!Prefs.token(this).isEmpty())showConnected();}

    private TextView tv(String s,int sp,boolean bold){ TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(ink);v.setGravity(Gravity.CENTER_HORIZONTAL); if(bold)v.setTypeface(null,1); return v; }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private void render(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER_HORIZONTAL);root.setPadding(dp(28),dp(54),dp(28),dp(28));root.setBackgroundColor(bg);
        TextView brand=tv("P R I N C I P I O",30,true);root.addView(brand,new LinearLayout.LayoutParams(-1,-2));
        TextView sub=tv("Tablet Notifier",18,false);sub.setTextColor(gold);LinearLayout.LayoutParams sm=new LinearLayout.LayoutParams(-1,-2);sm.setMargins(0,dp(8),0,dp(36));root.addView(sub,sm);
        status=tv("Collega questo tablet a un operatore del Manager.",16,false);root.addView(status,new LinearLayout.LayoutParams(-1,-2));
        pin=new EditText(this);pin.setHint("PIN operatore");pin.setInputType(2|16);pin.setTextSize(22);pin.setGravity(Gravity.CENTER);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(64));ip.setMargins(0,dp(24),0,dp(16));root.addView(pin,ip);
        login=new Button(this);login.setText("COLLEGA TABLET");login.setTextSize(17);login.setOnClickListener(v->doLogin());root.addView(login,new LinearLayout.LayoutParams(-1,dp(58)));
        Button open=new Button(this);open.setText("APRI PRINCIPIO MANAGER");open.setOnClickListener(v->openManager());LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,dp(54));op.setMargins(0,dp(14),0,0);root.addView(open,op);
        setContentView(root); if(!Prefs.token(this).isEmpty())showConnected();
    }
    private void doLogin(){
        String p=pin.getText().toString().trim(); if(p.length()<4){status.setText("Inserisci il PIN dell'operatore.");return;} login.setEnabled(false);status.setText("Collegamento ad Aruba…");
        Executors.newSingleThreadExecutor().execute(()->{try{
            JSONObject r=ApiClient.call("loginOperator",new JSONArray().put(p)); String token=r.getString("token"); JSONObject op=r.getJSONObject("operator"); String name=op.optString("name","Operatore");
            JSONObject reg=ApiClient.call("tabletNotifierRegister",new JSONArray().put(token).put(Prefs.deviceId(this)).put(BuildConfig.VERSION_NAME));
            Prefs.saveLogin(this,token,name);runOnUiThread(this::showConnected);
        }catch(Exception e){runOnUiThread(()->{login.setEnabled(true);status.setText("Errore: "+e.getMessage());});}});
    }
    private void showConnected(){
        pin.setVisibility(View.GONE);login.setText("SCOLLEGA TABLET");login.setEnabled(true);login.setOnClickListener(v->{stopService(new Intent(this,NotifierService.class));Prefs.clear(this);render();});
        status.setText("Operatore: "+Prefs.operator(this)+"\nNotifier operativo");
        requestRuntimePermissions();
        ContextCompatCompat.startForeground(this,new Intent(this,NotifierService.class));
    }
    private void requestRuntimePermissions(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},70);
        if(!Settings.canDrawOverlays(this)){
            status.setText("Operatore: "+Prefs.operator(this)+"\nAutorizza “Mostra sopra altre app”.");
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));
        }
    }
    private void openManager(){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(BuildConfig.MANAGER_BASE_URL)));}
    static final class ContextCompatCompat { static void startForeground(Context c,Intent i){ if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i); else c.startService(i); } }
}
