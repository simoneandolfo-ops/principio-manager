package it.principio.managernotifier;
import android.content.*;
import android.os.Build;
import android.provider.Settings;
public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){ if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())&&!Prefs.token(c).isEmpty()&&Settings.canDrawOverlays(c)){ Intent s=new Intent(c,NotifierService.class); if(Build.VERSION.SDK_INT>=26)c.startForegroundService(s);else c.startService(s);} }
}
