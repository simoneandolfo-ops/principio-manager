from pathlib import Path
import json
root=Path(__file__).parent
s=(root/'src/pages/SalaLivePage.jsx').read_text()
n=(root/'src/components/NotificationCenter.jsx').read_text()
p=(root/'package.json').read_text()
checks=['tablePressure','Priorità tavoli','Tavoli critici','Cambi entro 60 min','Conflitto stimato','pressure.level']
missing=[x for x in checks if x not in s]
assert not missing, f"CP24 missing: {missing}"
assert "nav(row.route==='/live'||row.id==='late'?'/live'" in n
version=json.loads(p).get('version','0.0.0-dev')
nums=tuple(int(x) for x in version.split('-')[0].split('.')[:3])
assert nums>=(0,17,0), f'CP24 frontend version too old: {version}'
print('CHECKPOINT 24 GUARD: PASS')
