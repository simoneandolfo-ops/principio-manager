#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node -e "const [maj,min]=process.versions.node.split('.').map(Number); if(!((maj===20&&min>=19)||(maj===22&&min>=12)||maj>22)){console.error('Node non compatibile: '+process.version);process.exit(2)}"
if [ ! -f package-lock.json ]; then
  echo 'RELEASE BUILD BLOCKED: package-lock.json missing. Generate and commit the lockfile before building.' >&2
  exit 3
fi
npm ci --ignore-scripts --no-audit --no-fund
npm run release:build
