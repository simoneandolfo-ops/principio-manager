#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node -e "const [maj,min]=process.versions.node.split('.').map(Number); if(!((maj===20&&min>=19)||(maj===22&&min>=12)||maj>22)){console.error('Node non compatibile: '+process.version);process.exit(2)}"
if [ -f package-lock.json ]; then
  echo 'BOOTSTRAP LOCK BLOCKED: package-lock.json already exists. Do not regenerate it casually.' >&2
  exit 3
fi
# This command is intentionally allowed only to create the first real lockfile.
# Release builds themselves remain npm-ci-only.
npm install --package-lock-only --ignore-scripts --no-audit --no-fund
node ./tools/check-release-input.cjs
npm ci --ignore-scripts --no-audit --no-fund
npm run release:build
