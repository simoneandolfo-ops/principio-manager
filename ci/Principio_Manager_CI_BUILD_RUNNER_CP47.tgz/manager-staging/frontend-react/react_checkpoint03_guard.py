#!/usr/bin/env python3
from pathlib import Path
import re,sys
r=Path(__file__).resolve().parent;root=r.parents[1];bad=[]
app=(r/'src/App.jsx').read_text(errors='ignore');api=(root/'manager-staging/public/api.php').read_text(errors='ignore');css=(r/'src/styles.css').read_text(errors='ignore')
for n in ['UniversalSearch','NotificationCenter','mobile-bottom-nav','navigator.onLine','visibilitychange','App Clienti']:
 if n not in app: bad.append('App missing '+n)
for n in ['searchReservations','restaurant_id=?','LIMIT 20']:
 if n not in api: bad.append('API search missing '+n)
for rel,names in [('src/components/UniversalSearch.jsx',['searchReservations','220','booking/']),('src/components/NotificationCenter.jsx',['pendingRequests','unassigned','late','managerBasePath']),('src/components/AppErrorBoundary.jsx',['getDerivedStateFromError','Ricarica'])]:
 t=(r/rel).read_text(errors='ignore')
 for n in names:
  if n not in t: bad.append(rel+' missing '+n)
for n in ['.universal-search','.notification-popover','.mobile-bottom-nav','.fatal-shell']:
 if n not in css: bad.append('CSS missing '+n)
# Verify every managerApi literal call is backed by a PHP API arm.
calls=set()
for p in list((r/'src').rglob('*.jsx'))+list((r/'src').rglob('*.js')):
 calls.update(re.findall(r"managerApi\(\s*['\"]([^'\"]+)['\"]",p.read_text(errors='ignore')))
fns=set(re.findall(r"^\s*'([A-Za-z0-9_]+)'\s*=>",api,re.M))
for fn in sorted(calls-fns):bad.append('React calls missing API '+fn)
if bad:
 print('REACT CHECKPOINT 03 GUARD: FAIL');print('\n'.join(bad));sys.exit(1)
print(f'REACT CHECKPOINT 03 GUARD: PASS ({len(calls)} API calls verified)')
