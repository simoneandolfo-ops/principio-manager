#!/usr/bin/env python3
from pathlib import Path
import sys
r=Path(__file__).resolve().parent
root=r.parents[1]
bad=[]
api=(r/'src/lib/api.js').read_text(errors='ignore')
editor=(r/'src/pages/BookingEditor.jsx').read_text(errors='ignore')
settings=(r/'src/pages/SettingsPage.jsx').read_text(errors='ignore')
hook=(r/'src/lib/useUnsavedChanges.js').read_text(errors='ignore')
php=(root/'manager-staging/public/api.php').read_text(errors='ignore')
boot=(root/'manager-staging/app/bootstrap.php').read_text(errors='ignore')
shared=(root/'shared/error_helpers.php').read_text(errors='ignore')
for n in ['RETRYABLE_READS','maxAttempts=RETRYABLE_READS.has(fn)?2:1','[502,503,504]']:
 if n not in api:bad.append('read retry missing '+n)
for forbidden in ["'createBooking'","'updateBooking'","'saveSettings'","'restoreTenantBackup'"]:
 line=api.split('RETRYABLE_READS=new Set(',1)[1].split(')',1)[0] if 'RETRYABLE_READS=new Set(' in api else ''
 if forbidden in line:bad.append('mutation accidentally retryable '+forbidden)
for n in ['useUnsavedChanges','dirty-badge','confirmDiscard']:
 if n not in editor:bad.append('BookingEditor unsaved guard missing '+n)
for n in ['useUnsavedChanges','dirty-badge','baselineRef']:
 if n not in settings:bad.append('Settings unsaved guard missing '+n)
for n in ['beforeunload','window.confirm','document.addEventListener']:
 if n not in hook:bad.append('unsaved hook missing '+n)
for n in ['function pm_error_status','function pm_safe_error','Errore interno. Riprova più tardi.']:
 if n not in shared:bad.append('shared error helper missing '+n)
for n in ["shared/error_helpers.php"]:
 if n not in boot:bad.append('manager bootstrap missing shared helpers')
for n in ['$operationalNow=pm_operational_now()','$today=$operationalNow->format']:
 if n not in php:bad.append('operational clock not unified '+n)
if 'DEV 15' not in php:bad.append('DEV15 changelog missing')
if bad:
 print('REACT CHECKPOINT 15 GUARD: FAIL');print('\n'.join(bad));sys.exit(1)
print('REACT CHECKPOINT 15 GUARD: PASS')
