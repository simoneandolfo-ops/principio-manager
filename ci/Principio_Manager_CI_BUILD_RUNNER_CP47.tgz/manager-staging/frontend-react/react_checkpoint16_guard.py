#!/usr/bin/env python3
from pathlib import Path
import sys
r=Path(__file__).resolve().parent
root=r.parents[1]
bad=[]
hook=(r/"src/lib/useUnsavedChanges.js").read_text(errors="ignore")
search=(r/"src/components/UniversalSearch.jsx").read_text(errors="ignore")
notifications=(r/"src/components/NotificationCenter.jsx").read_text(errors="ignore")
app=(r/"src/App.jsx").read_text(errors="ignore")
api=(root/"manager-staging/public/api.php").read_text(errors="ignore")

for n in ["confirmGlobalNavigation","__pmConfirmNavigation"]:
    if n not in hook:bad.append("unsaved global navigation missing "+n)
for n in ["StartupState","hydrating","Manager non raggiungibile","Errore sync"]:
    if n not in app:bad.append("startup/offline recovery missing "+n)
for name,text in [("UniversalSearch",search),("NotificationCenter",notifications),("App",app)]:
    if "confirmGlobalNavigation" not in text:bad.append(name+" does not respect unsaved navigation")

for kind in ["tv","tablet"]:
    js=(root/f"manager-staging/public/{kind}/{kind}.js").read_text(errors="ignore")
    for n in ["operationalNow","serverTimestamp","serverReceivedAt","operationalTime","Assegna un tavolo prima di accomodare"]:
        if n not in js:bad.append(f"{kind} missing {n}")
    if "new Date().toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit'})" in js:
        bad.append(f"{kind} still uses client clock for operational actions")

for n in ["previousStatus","effectiveTables","Assegna un tavolo prima di accomodare.","STATUS_WAITLIST","STATUS_ARRIVED"]:
    if n not in api:bad.append("Sala Live backend invariant missing "+n)
if "'newStatus'=>$previousStatus" not in api:
    bad.append("undo accommodation does not restore prior state")
for legacyClock in ["date('Y-m-d')","date('H:i')"]:
    if legacyClock in api:
        bad.append("operational API still uses server-default clock: "+legacyClock)

if bad:
    print("REACT CHECKPOINT 16 GUARD: FAIL");print("\n".join(bad));sys.exit(1)
print("REACT CHECKPOINT 16 GUARD: PASS")
