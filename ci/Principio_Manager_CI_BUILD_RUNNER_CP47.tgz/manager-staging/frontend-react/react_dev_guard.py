#!/usr/bin/env python3
from pathlib import Path
import re,sys
r=Path(__file__).resolve().parent
root=r.parents[1]
api=(root/"manager-staging/public/api.php").read_text(errors="ignore")
bad=[];calls=set()
for p in list((r/"src").rglob("*.jsx"))+list((r/"src").rglob("*.js")):
 t=p.read_text(errors="ignore")
 calls.update(re.findall(r"managerApi\(\s*['\"]([^'\"]+)['\"]",t))
 if "toISOString().slice(0,10)" in t:bad.append(str(p.relative_to(r))+" uses UTC date")
apiFns=set(re.findall(r"^\s*'([A-Za-z0-9_]+)'\s*=>",api,re.M))
for fn in sorted(calls-apiFns):bad.append("missing API "+fn)
app=(r/"src/App.jsx").read_text(errors="ignore")
for n in ["setCsrf(b?.csrfToken||'')","RequestsPage","StatisticsPage","pendingRequests"]:
 if n not in app:bad.append("App missing "+n)
req=(r/"src/pages/RequestsPage.jsx").read_text(errors="ignore")
for n in ["getPendingCustomerRequests","recommendSolution","confirmBooking","excludeBookingId"]:
 if n not in req:bad.append("Requests missing "+n)
stats=(r/"src/pages/StatisticsPage.jsx").read_text(errors="ignore")
for n in ["getStatistics","todayComparison","comparison","localShiftDays"]:
 if n not in stats:bad.append("Statistics missing "+n)
mapx=(r/"src/pages/MapPage.jsx").read_text(errors="ignore")
for n in ["getMapData","bookingDraft","fromMap","excludeBookingId","Usa nella prenotazione"]:
 if n not in mapx:bad.append("Map missing "+n)
editor=(r/"src/pages/BookingEditor.jsx").read_text(errors="ignore")
if "location.state?.fromMap" not in editor:bad.append("Editor overwrites map return")
if bad:
 print("REACT DEV GUARD: FAIL");print("\n".join(bad));sys.exit(1)
print(f"REACT DEV GUARD: PASS ({len(calls)} API calls verified)")
