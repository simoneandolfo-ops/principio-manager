#!/usr/bin/env python3
from pathlib import Path
import tarfile,tempfile,json,hashlib,shutil,sys,re
ROOT=Path(__file__).resolve().parents[1]
if len(sys.argv)!=2:
    print('usage: manager_import_frontend_build.py <Principio_Manager_FRONTEND_BUILD_RESULT.tgz>',file=sys.stderr);sys.exit(2)
arc=Path(sys.argv[1]).resolve()
if not arc.is_file(): print('IMPORT BLOCKED: result archive missing',file=sys.stderr);sys.exit(3)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    with tarfile.open(arc,'r:gz') as tf:
        for m in tf.getmembers():
            if m.name.startswith('/') or '..' in Path(m.name).parts: print('IMPORT BLOCKED: unsafe archive',file=sys.stderr);sys.exit(4)
        tf.extractall(td)
    evp=td/'frontend_build_evidence.json'; lock=td/'package-lock.json'; dist=td/'react-dist'
    if not evp.is_file() or not lock.is_file() or not (dist/'index.html').is_file() or not (dist/'.vite/manifest.json').is_file():
        print('IMPORT BLOCKED: incomplete build result',file=sys.stderr);sys.exit(5)
    ev=json.loads(evp.read_text()); pkg=json.loads((ROOT/'manager-staging/frontend-react/package.json').read_text())
    if ev.get('frontendVersion')!=pkg.get('version'): print('IMPORT BLOCKED: frontend version mismatch',file=sys.stderr);sys.exit(6)
    if ev.get('packageLockSha256')!=sha(lock): print('IMPORT BLOCKED: lock checksum mismatch',file=sys.stderr);sys.exit(7)
    files=ev.get('files') or {}
    actual={str(p.relative_to(dist)):sha(p) for p in sorted(dist.rglob('*')) if p.is_file()}
    if files!=actual: print('IMPORT BLOCKED: compiled asset checksums mismatch',file=sys.stderr);sys.exit(8)
    html=(dist/'index.html').read_text(errors='replace')
    if '/__PM_BASE__/react-dist/' not in html: print('IMPORT BLOCKED: deploy base placeholder missing',file=sys.stderr);sys.exit(9)
    targetlock=ROOT/'manager-staging/frontend-react/package-lock.json'; targetdist=ROOT/'manager-staging/public/react-dist'
    shutil.copy2(lock,targetlock)
    if targetdist.exists(): shutil.rmtree(targetdist)
    shutil.copytree(dist,targetdist)
    (ROOT/'qa/frontend_build_evidence_last.json').write_text(json.dumps(ev,indent=2,sort_keys=True)+'\n')
print('FRONTEND BUILD IMPORT: PASS')
