#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, subprocess, tarfile, sys

ROOT = Path(__file__).resolve().parents[1]
FR = ROOT / 'manager-staging' / 'frontend-react'
DIST = ROOT / 'manager-staging' / 'public' / 'react-dist'
LOCK = FR / 'package-lock.json'
OUT = ROOT / 'Principio_Manager_FRONTEND_BUILD_RESULT.tgz'
EVIDENCE = ROOT / 'frontend_build_evidence.json'

required = [LOCK, DIST / 'index.html', DIST / '.vite' / 'manifest.json']
missing = [str(p.relative_to(ROOT)) for p in required if not p.is_file()]
if missing:
    print('CI BUILD RESULT: FAIL - missing: ' + ', '.join(missing), file=sys.stderr)
    sys.exit(2)

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

pkg = json.loads((FR / 'package.json').read_text())
files = {
    str(p.relative_to(DIST)): sha(p)
    for p in sorted(DIST.rglob('*')) if p.is_file()
}
if not files:
    print('CI BUILD RESULT: FAIL - empty react-dist', file=sys.stderr)
    sys.exit(2)

evidence = {
    'format': 1,
    'frontendVersion': pkg['version'],
    'node': subprocess.check_output(['node', '-v'], text=True).strip(),
    'npm': subprocess.check_output(['npm', '-v'], text=True).strip(),
    'packageLockSha256': sha(LOCK),
    'files': files,
}
EVIDENCE.write_text(json.dumps(evidence, indent=2, sort_keys=True) + '\n')
with tarfile.open(OUT, 'w:gz') as tf:
    tf.add(LOCK, arcname='package-lock.json')
    tf.add(DIST, arcname='react-dist')
    tf.add(EVIDENCE, arcname='frontend_build_evidence.json')
checksum = sha(OUT)
(ROOT / 'Principio_Manager_FRONTEND_BUILD_RESULT.sha256').write_text(
    checksum + '  ' + OUT.name + '\n'
)
print('CI BUILD RESULT: PASS')
print(OUT)
print(checksum)
